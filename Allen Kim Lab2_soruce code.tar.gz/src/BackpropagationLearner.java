// ----------------------------------------------------------------
// Author: Allen Kim
// Created on: 1/28/15
// ----------------------------------------------------------------

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;

/**
 * For nominal labels, this model simply returns the majority class. For
 * continuous labels, it returns the mean value.
 * If the learning model you're using doesn't do as well as this one,
 * it's time to find a new learning model.
 */
public class BackpropagationLearner extends SupervisedLearner {

	double[] m_labels;
	ArrayList<double[][]> layers = new ArrayList<double[][]>();
	ArrayList<double[][]> dLayers = new ArrayList<double[][]>();

	Random random;
	double trainPercent = 0.75;
	int num_output = 0;
	double[] target;
	double biasInput = 1;
	double c = 0.1; // learning rate
	double momentum = 0.3;

	int[] num_nodes;
	int num_inputNodes;
	int num_hiddenLayers = 2;		//initialize number of hidden layers
	int num_hiddenNodes;			//for now all hidden layers will hold the same number of nodes
	int num_outputNodes;
		
	double curOutput = 0;
	
	double predOutputs;
	
	double MSE_Test = 0;
	double total_MSE = 0;
	PrintWriter outFile_3;
	
	public BackpropagationLearner(Random rand){
		random = rand;
		try {
			outFile_3 = new PrintWriter("NUM3.txt");
			outFile_3.print(num_hiddenLayers + " ");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	

	public void train(Matrix features, Matrix labels) throws Exception {
		
		initWeights(features, labels);
		target = new double[num_outputNodes];
		
		
		
		
		PrintWriter outFile = new PrintWriter("MSE_TS.txt");
		PrintWriter outFile2 = new PrintWriter("MSE_VS.txt");
		PrintWriter outFile3 = new PrintWriter("accuracy.txt");
		
		features.shuffle(random, labels);
		int trainSize = (int)(trainPercent * features.rows());
		Matrix trainFeatures = new Matrix(features, 0, 0, trainSize, features.cols());
		Matrix trainLabels = new Matrix(labels, 0, 0, trainSize, 1);
		Matrix testFeatures = new Matrix(features, trainSize, 0, features.rows() - trainSize, features.cols());
		Matrix testLabels = new Matrix(labels, trainSize, 0, features.rows() - trainSize, 1);
		
		int max_window = 100;
		int window = max_window;
		double bssf = 1;
		double mse_bssf = 1;
		int stop = 0;
		
		Queue<Double> prev = new LinkedList<Double>(); 
		

		
		int cnt = 0;
		while(true){
			
			cnt++;
			System.out.println("cnt: " + cnt);
			//forward
			for(int i = 0; i < trainFeatures.rows(); i++){
				double[] input = trainFeatures.row(i);
				setTarget(trainLabels.get(i, 0));
				recNode(0, input);
				updateAllLayers();
			}
			double curAccuracy = accuracy(testFeatures, testLabels);
			double MSE_TS = mse(trainFeatures, trainLabels);
			double MSE_VS = mse(testFeatures, testLabels);
			outFile.println(MSE_TS);
			outFile2.println(MSE_VS);
			outFile3.println(curAccuracy);
			
			System.out.println("Accuracy:\t" + curAccuracy);
//			System.out.println("MSE TS: " + MSE_TS);
//			System.out.println("MES VS: " + MSE_VS);
//			System.out.println();

			
			if(prev.size() == window){
				double min = min(prev);
				System.out.println("Min:\t\t" + min);
				if(min >= curAccuracy){
					outFile_3.print(MSE_TS + " " + MSE_VS + " " + curAccuracy + " " + cnt + " ");
					System.out.println("iteration: " + cnt);
					break;
				}
				prev.remove();				
			}
			prev.add(curAccuracy);
			
			trainFeatures.shuffle(random, trainLabels);
		}
		outFile.close();
		outFile2.close();
		outFile3.close();
//		featureSelection();
	}
	
	public void updateAllLayers(){
		for(int l = 0; l < layers.size(); l++){
			double[][] layer = layers.get(l);
			double[][] dLayer = dLayers.get(l);
			double[][] newLayer = new double[layer.length][layer[0].length];
			for(int i = 0; i < layer.length; i++){
				for(int j = 0; j < layer[0].length; j++){
					newLayer[i][j] = layer[i][j] + dLayer[i][j];
				}
			}
			layers.set(l, newLayer);
		}
	}
	
	public double[] recNode(int l_index, double[] input){
		if(l_index == layers.size())
			return null;
		double[] outputs = new double[layers.get(l_index).length];
		double[][] layer = layers.get(l_index);
		double[] thetas = new double[layers.get(l_index).length];
		
		//get outputs
		for(int i = 0; i < outputs.length; i++){
			outputs[i] = calcOutput(layer[i], input);
		}

		//recurse to get next outputs
		double[] nextThetas = recNode(l_index + 1, outputs);
		
		//update weights for this layer
		if(nextThetas == null){		//output layer
			for(int i = 0; i < outputs.length; i++){
				double theta = calcOutputTheta(outputs[i], target[i]);
				calcWeightUpdate(theta, input, l_index, i);
				thetas[i] = theta;
			}
			curOutput = maxIndex(outputs);
//			printArray(outputs);
		}else{							//hidden layer
			for(int i = 0; i < outputs.length; i++){
				double[] w = getWeightsFrom(i, layers.get(l_index + 1));
				double theta = calcHiddenTheta(outputs[i], nextThetas, w);
				calcWeightUpdate(theta, input, l_index, i);
			}
		}
		
		return thetas;
	}
	
	public double[] getWeightsFrom(int n_index, double[][] nextLayer){
		double[] w = new double[nextLayer.length];
		for(int i = 0; i < w.length; i++){
			w[i] = nextLayer[i][n_index];
		}
		return w;
	}
	
	public double calcHiddenTheta(double o, double[] t, double[] w){
		double theta = o*(1-o);
		double sum = 0;
		for(int i = 0; i < t.length; i++){
			sum += t[i] * w[i];
		}
		theta *= sum;
		return theta;
	}
	
	public void calcWeightUpdate(double theta, double[] input, int l_index, int n_index){
		double[][] node = dLayers.get(l_index);
		double dw = c * theta * 1;
		node[n_index][0] = dw + (momentum*node[n_index][0]);
		for(int i = 0; i < input.length; i++){
			dw = c * theta * input[i];
			node[n_index][i+1] = dw  + (momentum*node[n_index][i+1]);
		}
		dLayers.set(l_index, node);
	}
	
	public double calcOutputTheta(double o, double t){
		double theta = (t - o) * o * (1 - o);
		return theta;
	}
	
	public double calcOutput(double[] weights, double[] input){
		double net = biasInput * weights[0];
		double output = 0;
		for(int i = 0; i < input.length; i++){
			net += input[i] * weights[i+1];
		}
		output = 1 / (1 + Math.exp(-net));
		
		return output;
	}
	
	public void setTarget(double t){
		for(int i = 0; i < target.length; i++){
			if(i == t)
				target[i] = 1;
			else
				target[i] = 0;
		}
	}
	
	public void initWeights(Matrix features, Matrix labels){
		num_inputNodes = features.cols();
		num_outputNodes = labels.valueCount(0);
		num_nodes = new int[num_hiddenLayers + 2];
//		num_hiddenNodes = (num_inputNodes * 2);
		num_hiddenNodes = 128;
//		outFile_3.print(num_hiddenNodes + " ");
		Arrays.fill(num_nodes, num_hiddenNodes);
		num_nodes[0] = num_inputNodes;
		num_nodes[num_nodes.length-1] = num_outputNodes;
		
		
		for(int l = 1; l < num_nodes.length; l++){
			double[][] layer = new double[num_nodes[l]][num_nodes[l-1]+1];
			double[][] dLayer = new double[num_nodes[l]][num_nodes[l-1]+1];
			for(int i = 0; i < num_nodes[l]; i++){
				for(int j = 0; j < num_nodes[l-1]+1; j++){
					layer[i][j] = generateRandomWeight(num_nodes[l],num_nodes[l-1]);
				}
			}
//			System.out.println();
			layers.add(layer);
			dLayers.add(dLayer);
		}	
	}
	
	public double predictOutput(int l_index, double[] input){
		if(l_index == layers.size())
			return -1;
		double[] outputs = new double[layers.get(l_index).length];
		double[][] layer = layers.get(l_index);
		for(int i = 0; i < outputs.length; i++){
			outputs[i] = calcOutput(layer[i], input);
		}
		//recurse 
		double nextOutput = predictOutput(l_index + 1, outputs);
		
		//update weights for this layer
		if(nextOutput == -1){		//output layer
			predOutputs = outputs[maxIndex(target)];
			return maxIndex(outputs);		
		}
		
		return nextOutput;
	}

	public double mse(Matrix features, Matrix labels) throws Exception{
		double mse = 0;
		double[] prediction = new double[1];
		for(int i = 0; i < features.rows(); i++){
			double[] feat = features.row(i);
			setTarget(labels.get(i, 0));
			predict(feat, prediction);
			mse += Math.pow((1-predOutputs), 2);
		}
		return mse/features.rows();
	}
	
	public double accuracy(Matrix features, Matrix labels) throws Exception{
		int correctCount = 0;
		double[] prediction = new double[1];
		for(int i = 0; i < features.rows(); i++)
		{
			double[] feat = features.row(i);
			int targ = (int)labels.get(i, 0);
			predict(feat, prediction);
			int pred = (int)prediction[0];
			if(pred == targ)
				correctCount++;
		}
		return (double)correctCount / features.rows();
	}
	

	public void predict(double[] features, double[] labels) throws Exception {
		labels[0] = predictOutput(0, features);
	}
	
	public void predict(double[] features, int target) throws Exception {
		double[] prediction = new double[1];
		setTarget(target);
		predict(features, prediction);
		MSE_Test += Math.pow((1-predOutputs), 2);
		total_MSE++;
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public void featureSelection(){
		double[][] layer = layers.get(0);
		double[] weights = new double[num_inputNodes];
		for(int i = 0; i < num_inputNodes; i++){
			double sum = 0;
			for(int j = 0; j < layer.length; j++){
				sum += layer[j][i+1];
			}
			weights[i] = sum / layer.length;
		}
		System.out.println("feature selection");
		printArray(weights);
	}
	
	public void printTestMSE(double acc){
		double mse = MSE_Test/total_MSE;
		outFile_3.print(mse + " " + acc + "\n");
		outFile_3.close();
	}
	

	//=======================================================================================================//
	// help function
	
	public double avg(Queue<Double> list){
		double sum = 0;
		for(double d: list){
			sum += d;
		}
		return sum / list.size();
	}
	
	public double generateRandomWeight(int n1, int n2){
		double range = Math.sqrt(6.0)/Math.sqrt((double)n1 + (double)n2);
		double rand = 0;
		rand = (random.nextDouble() * 2 * range) - range;
		return rand;
	}
	
	public int maxIndex(double[] nets){
		int index = 0;
		double max = nets[0];
		for(int i = 1; i < nets.length; i++){
			if(max < nets[i]){
				max = nets[i];
				index = i;
			}	
		}
		return index;
	}
	public void printArray(double[] array){
		for(double d: array){
			System.out.println(d);
		}
		System.out.println();
	}
	
	public double min(Queue<Double> list){
		double min = 1;
		for(double d: list){
			if(d < min)
				min = d;
		}
		return min;
	}
}
