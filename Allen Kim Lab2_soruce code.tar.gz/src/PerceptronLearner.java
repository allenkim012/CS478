// ----------------------------------------------------------------
// Author: Allen Kim
// Created on: 1/28/15
// ----------------------------------------------------------------

import java.util.*;

/**
 * For nominal labels, this model simply returns the majority class. For
 * continuous labels, it returns the mean value.
 * If the learning model you're using doesn't do as well as this one,
 * it's time to find a new learning model.
 */
public class PerceptronLearner extends SupervisedLearner {

	double[] m_labels;
	ArrayList< double[] > weights;
	Random random;
	int num_output = 0;
	double biasInput = -1;
	double num_store_accuracy = 30;
	double c = 0.01; // learning rate
	public PerceptronLearner(Random rand){
		random = rand;
	}	

	public void train(Matrix features, Matrix labels) throws Exception {
		
		
		
		num_output = labels.valueCount(0);
		System.out.println("\nTraining start");
		weights = new ArrayList< double[] >();
		
		if(num_output <= 2){
			double[] w = new double[features.cols()+1];
			for(int j = 0; j < w.length; j++){
				w[j] = random.nextDouble();
			}
			weights.add(w);
		}else{
			for(int i = 0; i < num_output; i++){
				double[] w = new double[features.cols()+1];
				for(int j = 0; j < w.length; j++){
					w[j] = random.nextDouble();
				}
				weights.add(w);
			}
		}

		Queue<Double> prev = new LinkedList<Double>(); 
		int totalCnt = 0;
		while(true){
			if(num_output <= 2){
				for(int r=0; r < features.rows(); r++){
					double[] row = features.row(r);
					double t = labels.get(r, 0);
					double z = pTraining(row, 0);
					double diff = z - t;
					if(diff != 0)
						updateWeight(diff, row, 0);
				}
				num_store_accuracy = 50;
			}
			else{
				for(int r=0; r < features.rows(); r++){
					double[] row = features.row(r);
					double l = labels.get(r, 0);
					
					for(int i = 0; i < weights.size(); i++){
						double z = pTraining(row, i);
						double t = 0;
						if(l == i)
							t = 1;					
						double diff = z - t;
						if(diff != 0){
							updateWeight(diff, row, i);
						}
					}
				}
			}
			
			double curAccuracy = accuracy(features, labels);
			System.out.print(", " + (1 - curAccuracy));

			prev.add(curAccuracy);
			if(prev.size() == num_store_accuracy){
				double avg = avg(prev);
				double diff = Math.abs(curAccuracy - avg);
				if(diff < 0.01){
					System.out.println("\nTotal iteration: " + totalCnt);
					break;
				}
				prev.remove();				
			}

//			if(curAccuracy > .95)
//				break;
			features.shuffle(random,labels);
			totalCnt++;
		}
		
		printArray(weights.get(0));

//		printWeightFomula(0);
	}
	
	public void printWeightFomula(int index){
		double[] weight = weights.get(index);
		String f = "y = (";
		f += Double.toString(weight[0]);
		f += " - x * ";
		f += Double.toString(weight[1]);
		f += ") / ";
		f += Double.toString(weight[2]);
		
		System.out.println(f);
	}
	
	public void printQueue(Queue<Double> list){
		System.out.print("Queue: ");
		for(double d: list){
			System.out.println(" " + d);
		}
		System.out.println();
	}
	
	public double avg(Queue<Double> list){
		double sum = 0;
		for(double d: list){
			sum += d;
		}
		return sum / list.size();
	}
	
	public double accuracy(Matrix features, Matrix labels) throws Exception{
		int correctCount = 0;
		double[] prediction = new double[1];
		for(int i = 0; i < features.rows(); i++)
		{
			double[] feat = features.row(i);
			int targ = (int)labels.get(i, 0);
			predict(feat, prediction);
			int pred = (int)prediction[0];
			if(pred == targ)
				correctCount++;
		}
		return (double)correctCount / features.rows();
	}
	
	public void updateWeight(double diff, double[] row, int index){
		double[] weight = weights.get(index);
		double[] newWeight = new double[weight.length];
		newWeight[0] = weight[0] - c * diff * biasInput;
		for(int i = 0; i < row.length; i++){
			newWeight[i+1] = weight[i+1] - (c * diff * row[i]);
		}
		weights.set(index, newWeight);
	}
	
	public double pTraining(double[] row, int wIndex){
		double[] weight = weights.get(wIndex);
		double net = biasInput * weight[0];
		for(int i = 0; i < row.length; i++){
			net += row[i] * weight[i+1];
		}
		if(net > 0){
			return 1;
		}
		return 0;
	}
	
	public void printArray(double[] array){
		for(double d: array){
			System.out.println(d);
		}
		System.out.println();
	}
	
	public double[] getOutputArray(double t){
		double[] output = new double[weights.size()];
		for(int i = 0; i < output.length; i++){
			if(t == i)
				output[i] = 1;
			else
				output[i] = 0;
		}
		return output;
	}
	
	public double calcTestingOutput(double[] row){
		double[] nets = new double[weights.size()]; 
		for(int i = 0; i < weights.size(); i++){
			double[] w = weights.get(i);
			double net = w[0] * biasInput;	//weights[0] is bias
			for(int j = 0; j < row.length; j++ ){
				net += w[j + 1] * row[j];
			}
			nets[i] = net;
		}
//		System.out.println(nets[0]);
		if(num_output == 2){
			if(nets[0] > 0)
				return 1;
			return 0;
		}
		
		int maxindex = maxIndex(nets);
		return maxindex;
	}
		
	public int maxIndex(double[] nets){
		int index = 0;
		double max = nets[0];
		for(int i = 1; i < nets.length; i++){
			if(max < nets[i]){
				max = nets[i];
				index = i;
			}	
		}
		return index;
	}
	

	public void predict(double[] features, double[] labels) throws Exception {
			labels[0] = calcTestingOutput(features);
//			System.out.println();
	}

	@Override
	public void predict(double[] features, int targ) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printTestMSE(double acc) {
		// TODO Auto-generated method stub
		
	}

}
